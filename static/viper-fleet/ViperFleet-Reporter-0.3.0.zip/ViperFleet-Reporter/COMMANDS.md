# Viper Fleet queued payloads — 0.3 development pilot

ViperLink can queue its existing ordered payloads through CloudKit. A managed
Mac, Windows PC, or Linux machine retrieves jobs over outbound HTTPS; it does
not need to share the controller's LAN, use Bonjour, or accept inbound ports.
The receiver runs as its user, without sudo or an elevation mechanism.

## Enroll a receiver

Use Node.js 22 or later and a registered private reporting profile from the
direct-report setup. Apply `schema.ckdb` to the dedicated ViperFleet development
container, preserving its existing roles. The additional types are
`ViperFleetCommand` and `ViperFleetBlob`. FleetAdmin and FleetReporter may
create/read/write those types. Neither type grants World or Authenticated access.

On your administrator machine, create a NEW private directory outside Git:

```sh
node enroll-commands.mjs --reporter /private/reporter-profile.json \
  --directory /private/new-machine --root '/Users/operator/ViperLink Shared' \
  --name 'Managed Mac' --minutes 5
```

Use that target machine's absolute shared-folder path. Create the shared
folder before running its receiver; it must be a real directory without
symlink components. The command does not contact Apple or enable execution.
For each new machine it generates a distinct device UUID and 256-bit command
key. Distribute only that machine's `receiver.json` and `fleet-private.pem`
privately to it. Protect the directory and files (700/600 on Unix; a private
user-only ACL on Windows). Never publish enrollment files or put them in Git.

Keep `controller.json` on authorized ViperLink controllers. Keep
`command-keys.json` on authorized web administrators. The latter contains only
per-machine command keys, not the server signing key. A controller profile may
contain multiple explicitly enrolled devices; importing another profile in
ViperLink merges devices only for the same container, environment and server key.

## Choose the check-in interval in RedAgent

1. Open **RedAgent → Cloud Fleet** and choose the machine's `receiver.json`.
2. Set **Check in every X minutes**, from 1 to 1,440; default is 5.
3. Enable **cloud commands while RedAgent is open**.
4. Use **Apply interval** to change the running schedule or **Check in now**
   to request a check as soon as the current payload finishes.

The interval begins after a check-in finishes; long payloads do not overlap.
The setting persists in the private profile. Closing RedAgent stops its owned
receiver and disables it; enable it again after reopening. The separate CLI
is available for deliberate service integration, but no login item or system
service is installed:

```sh
# First deliberately set enabled=true in this receiver's private profile.
node queue-agent.mjs --profile /private/machine/receiver.json --once
node queue-agent.mjs --profile /private/machine/receiver.json --watch
```

The visible receiver reports hostname, OS/kernel/architecture, version and
check-in time. Its zero inventory counters are tagged `inventory-not-run`;
it does not collect the installed-application inventory. RedAgent's explicit
inventory tests remain separate. Status reports and command results are
different records.

## Submit from ViperLink on macOS or iOS

Import the private `controller.json` in **Cloud Fleet** once; ViperLink stores
it in Keychain. Administrators can preprovision `FleetBootstrap.json` in the
app's normal data directory; the app imports and removes it at launch.

Build or load a plan in **Payloads**, including command/upload/download steps.
In **Cloud Fleet**, select its machine, review the payload name and step count,
choose an expiry (1–168 hours; default 24), and choose **Queue payload for next
check-in**. LAN connection state does not affect cloud submission.

Refresh the latest 100 jobs and choose **Verify receipt**. Queue acceptance is
not execution. Only a decrypted authenticated result is shown as a receipt.
Returned files are SHA-256 checked, saved without overwriting a different file,
and available through the existing share control. iOS is a controller; it does
not execute a shell locally.

## Submit from the web portal

At https://www.orbitusrobotics.com/viper-fleet/ sign in with the authorized Apple
account, then select **Queue a payload**. Import `command-keys.json` and the
`.viperpayload.json` file produced by ViperLink's **Export current payload for
web portal**. Review the destination, exact ordered commands and expiry before
queueing. The exported payload includes its upload files; treat it as private.

The portal keeps keys, decrypted payloads and receipts in page memory only.
Signing out clears them. Queue submission sends ciphertext, never those keys,
to CloudKit. File downloads become explicit browser download links after their
hash is verified. The page's public source and reporter download contain no
enrollment credentials.

For command-line administration:

```sh
node queue-submit.mjs --profile /private/controller.json --target DEVICE_UUID \
  --plan /private/payload.json --files /private/PayloadFiles --hours 24
node queue-submit.mjs --profile /private/controller.json --target DEVICE_UUID \
  --result JOB_UUID
```

## Execution and recovery contract

- Same version-1 ViperLink plan: 1–1,000 steps, executed linearly. The first
  failing command or file step stops the plan. Commands have 1–300 second
  timeouts; per-command output is limited to 64 KiB, and total command output
  to 1 MiB. No interactive prompt or privileged execution is provided.
- A cloud payload carries at most 8 MiB of upload files and at most 16 MiB of
  encoded content. Returned files total at most 8 MiB. Use Bonjour for larger
  transfers. Files use portable basenames in the selected shared folder;
  symlinks and overwriting existing upload names are rejected.
- AES-256-GCM authenticates the complete message, bound to target UUID, job UUID
  and request/result direction. Encrypted messages are split into 256 KiB
  chunks, checked against a SHA-256 manifest, then decrypted. Upload digests
  and all plan structure are validated before executing any step.
- Jobs expire within seven days. The local journal is fsynced before claiming
  or executing a step. Each job UUID is attempted at most once while that
  journal is retained. A crash or ambiguous network claim is reported as
  interrupted, not automatically retried. Review effects before submitting
  a NEW job. This is not an exactly-once guarantee: interrupted commands may
  have had effects even if no successful receipt arrived.
- Receipt publication can retry after a connection failure without executing
  the plan again. Keep the journal when moving/reinstalling the receiver;
  losing it also loses its local replay history. Do not clone a receiver
  profile and journal onto another simultaneously running host.
- A check-in attempts up to ten eligible jobs; remaining jobs wait for the
  next interval. Queues are bounded to 10,000 records per machine in this pilot;
  archive old completed jobs before reaching the limit. The native and web
  lists show the newest 100 jobs.
- Stopping the receiver cancels its owned command process tree. There is no
  remote emergency-cancel feature for an already running job. Offline machines
  cannot receive immediate changes. Host clocks must be synchronized for
  signing and expiry checks.

## Credentials and limits

The existing CloudKit server credential is a shared transport credential. Its
holders can read, alter or delete fleet records, including encrypted queue
records, through the key owner's roles. CloudKit roles attach to that owner,
not to an individual server key. Separate server keys from the same owner do
not create separate command-authoring permissions.

The additional unique machine key provides command authentication and payload
confidentiality despite that shared transport. Another reporting machine cannot
decrypt or forge this machine's jobs/results without its command key. It can
still disrupt transport, delete records, or change unauthenticated queue status.
This is why execution is established by an authenticated receipt rather than
the record's status text. Any authorized holder of a machine's symmetric key
can also forge its receipts; these are not hardware attestation.

To revoke cloud execution for a machine, disable its receiver and rotate its
command key locally and on authorized controllers. Removing a device from one
controller or hiding the website does not revoke another copy of its key.
Revoke the shared CloudKit key in Apple if transport credentials are exposed;
all clients using it will need replacement provisioning.

This feature does not turn CloudKit into an MDM server. Local Fleet MDM remains
a separate service. No MDM enrollment, APNs management, OS policy installation,
port-forwarding, Cloudflare service, or automatic endpoint-wide deployment is
performed by this feature. Production schema/roles must be activated separately
from this development pilot.

## Validation

`node --test direct.test.mjs queue.test.mjs` exercises signatures, encryption,
target/direction binding, file corruption, invalid plans, actual shell output
and timeout, sequential failure, expired requests, receipt retry and interrupted
journals. Swift tests decode a Node-generated ciphertext fixture and verify
native encryption/transfer behavior. RedAgent tests its interval/private-profile
controls and the bundled receiver hashes. These checks do not by themselves
prove that a remote physical Windows/Linux machine has executed a payload.
