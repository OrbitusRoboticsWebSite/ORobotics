#!/usr/bin/env node
import { readFile, lstat, realpath } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { privateJSON } from './queue-agent.mjs';
import { FleetCloud, putMessage, getMessage } from './queue-cloud.mjs';
import { validateCredentials } from './cloudkit.mjs';
import { check, uuid, validatePlan, validateBundle, fleetLimits, bytes64, sha256, seal, unseal } from './queue-format.mjs';

export async function bundlePlan(plan, folder) {
  validatePlan(plan); const files = Object.create(null); let total = 0;
  for (const step of plan.steps) if (step.kind === 'upload' && !Object.hasOwn(files, step.file)) {
    const file = path.resolve(folder, step.file), st = await lstat(file);
    check(st.isFile() && !st.isSymbolicLink() && path.dirname(await realpath(file)) === await realpath(folder), 'Uploads must be regular files in the chosen payload folder');
    total += st.size; check(total <= fleetLimits.fileBytes, 'Cloud uploads total at most 8 MiB');
    const data = await readFile(file); files[step.file] = { size: data.length, sha256: await sha256(data), data: bytes64(data) };
  }
  return validateBundle({ plan, files });
}
export async function submit(cloud, device, bundle, { now = Date.now(), expiresHours = 24, jobId = crypto.randomUUID() } = {}) {
  await validateBundle(bundle); check(uuid.test(device.deviceId) && uuid.test(jobId) && Number.isFinite(expiresHours) && expiresHours > 0 && expiresHours <= 168, 'Invalid destination or expiry');
  const request = { version: 1, deviceId: device.deviceId, jobId, createdAt: new Date(now).toISOString(), expiresAt: new Date(now + expiresHours * 3600000).toISOString(), bundle };
  const encrypted = await seal(request, device.commandKey, 'request', device.deviceId, jobId);
  const requestJSON = await putMessage(cloud, encrypted, device.deviceId, jobId, 'request');
  const record = await cloud.save({ recordType: 'ViperFleetCommand', recordName: `job-${jobId}`, fields: {
    deviceId: { value: device.deviceId }, jobId: { value: jobId }, createdAt: { value: now, type: 'TIMESTAMP' },
    status: { value: 'queued' }, requestJSON: { value: requestJSON }, resultJSON: { value: '' } } }, true);
  return { queued: true, executed: false, jobId, deviceId: device.deviceId, receivedAt: new Date(record.modified.timestamp).toISOString(), expiresAt: request.expiresAt };
}
export async function readResult(cloud, device, jobId) {
  check(uuid.test(jobId), 'Invalid job ID'); const record = await cloud.lookup(`job-${jobId}`);
  check(record?.fields?.deviceId?.value === device.deviceId, 'Job unavailable for this machine');
  if (!record.fields.resultJSON?.value) return { jobId, authenticated: false, transportStatus: record.fields.status?.value, message: 'Awaiting a device-authenticated result' };
  const m = await getMessage(cloud, record.fields.resultJSON.value, jobId, 'result');
  const receipt = await unseal(m.descriptor, m.chunks, device.commandKey, 'result', device.deviceId, jobId);
  check(receipt.version === 1 && receipt.deviceId === device.deviceId && receipt.jobId === jobId, 'Receipt identity mismatch');
  return { ...receipt, authenticated: true };
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2), o = {};
    for (let i = 0; i < args.length; i += 2) { check(['--profile', '--target', '--plan', '--files', '--hours', '--result'].includes(args[i]) && args[i + 1] && !o[args[i]], 'Invalid queue arguments'); o[args[i]] = args[i + 1]; }
    const p = await privateJSON(path.resolve(o['--profile']), 1048576), device = p.devices?.find(d => d.deviceId === o['--target']);
    check(p.version === 1 && device, 'Choose an enrolled target from this controller profile');
    const credentials = { ...p, privateKey: p.privateKeyPEM }; validateCredentials(credentials); const cloud = new FleetCloud(credentials);
    if (o['--result']) console.log(JSON.stringify(await readResult(cloud, device, o['--result']), null, 2));
    else {
      const st = await lstat(o['--plan']); check(st.isFile() && st.size <= fleetLimits.bundleBytes, 'Invalid plan file');
      const plan = JSON.parse(await readFile(o['--plan'], 'utf8'));
      console.log(JSON.stringify(await submit(cloud, device, await bundlePlan(plan, path.resolve(o['--files'] || path.dirname(o['--plan']))), { expiresHours: Number(o['--hours'] || 24) }), null, 2));
    }
  } catch (e) { console.error(JSON.stringify({ error: e.message })); process.exitCode = 1; }
}
