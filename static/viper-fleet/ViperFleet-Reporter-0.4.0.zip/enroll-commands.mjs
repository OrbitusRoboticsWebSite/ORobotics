#!/usr/bin/env node
import { mkdir, writeFile, lstat } from 'node:fs/promises';
import path from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { loadProfile } from './report-direct.mjs';
import { check, intervalMinutes } from './queue-format.mjs';

export async function enroll({ reporter, directory, root, name, minutes = 5 }) {
  intervalMinutes(minutes); check(path.isAbsolute(directory) && path.isAbsolute(root) && typeof name === 'string' && name.trim() && name.length <= 80, 'Use absolute private/shared folders and a host name');
  for (let p = path.resolve(directory); ; p = path.dirname(p)) {
    try { await lstat(path.join(p, '.git')); throw new Error('Enrollment credentials must stay outside Git'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    if (p === path.dirname(p)) break;
  }
  const credentials = await loadProfile(path.resolve(reporter));
  await mkdir(directory, { mode: 0o700 }); // no overwrite and no recursive creation
  const deviceId = randomUUID(), commandKey = randomBytes(32).toString('base64');
  const common = { container: credentials.container, environment: credentials.environment, keyID: credentials.keyID };
  const device = { deviceId, name, commandKey };
  async function put(file, value) { await writeFile(path.join(directory, file), typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', { mode: 0o600, flag: 'wx' }); }
  await put('fleet-private.pem', credentials.privateKey);
  await put('receiver.json', { version: 1, ...common, ...device, privateKeyFile: 'fleet-private.pem', root: path.resolve(root), intervalMinutes: minutes, enabled: false });
  await put('controller.json', { version: 1, ...common, privateKeyPEM: credentials.privateKey, devices: [device] });
  await put('command-keys.json', { version: 1, container: common.container, environment: common.environment, devices: [device] });
  return { enrolled: true, enabled: false, deviceId, directory, intervalMinutes: minutes };
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2), options = {};
    for (let i = 0; i < args.length; i += 2) { check(['--reporter', '--directory', '--root', '--name', '--minutes'].includes(args[i]) && args[i + 1] && !options[args[i]], 'Invalid enrollment arguments'); options[args[i]] = args[i + 1]; }
    console.log(JSON.stringify(await enroll({ reporter: options['--reporter'], directory: options['--directory'], root: options['--root'], name: options['--name'], minutes: Number(options['--minutes'] || 5) })));
  } catch (e) { console.error(JSON.stringify({ error: e.message })); process.exitCode = 1; }
}
