import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm, symlink, realpath } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomUUID, randomBytes } from 'node:crypto';
import { seal, unseal, validateBundle, intervalMinutes, filename, bytes64, sha256, validateRequest } from './queue-format.mjs';
import { submit, readResult } from './queue-submit.mjs';
import { executeBundle, commandStep, processJob, durableJSON } from './queue-agent.mjs';

const device = () => ({ deviceId: randomUUID(), name: 'Invented test host', commandKey: randomBytes(32).toString('base64') });
const step = (kind = 'command', extra = {}) => ({ id: randomUUID(), kind, command: 'echo test', file: '', remoteName: '', timeout: 5, ...extra });
const bundle = (steps = [step()]) => ({ plan: { version: 1, id: randomUUID(), name: 'Test payload', steps }, files: {} });
class MemoryCloud {
  records = new Map(); counter = 0; failReceipt = false;
  async lookup(name) { return structuredClone(this.records.get(name) || null); }
  async save(record, create = false) {
    const current = this.records.get(record.recordName);
    if (create ? current : !current || current.recordChangeTag !== record.recordChangeTag) throw new Error('Conflict');
    if (this.failReceipt && record.fields.resultJSON?.value) { this.failReceipt = false; throw new Error('Connection lost'); }
    const r = structuredClone({ ...record, recordChangeTag: String(++this.counter), modified: { timestamp: Date.now() } });
    this.records.set(r.recordName, r); return structuredClone(r);
  }
}
async function fixture(t) {
  const directory = await realpath(await mkdtemp(path.join(os.tmpdir(), 'fleet-queue-test-'))); t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(path.join(directory, 'journal')); const root = path.join(directory, 'shared'); await mkdir(root);
  return { ...device(), directory, root };
}
test('encrypted multi-chunk jobs bind target, job ID, direction and key', async () => {
  const d = device(), id = randomUUID(), value = { text: 'x'.repeat(400000) }, encrypted = await seal(value, d.commandKey, 'request', d.deviceId, id);
  assert.equal(encrypted.chunks.length, 2);
  assert.deepEqual(await unseal(encrypted.descriptor, encrypted.chunks, d.commandKey, 'request', d.deviceId, id), value);
  for (const [secret, purpose, target, job] of [[device().commandKey, 'request', d.deviceId, id], [d.commandKey, 'result', d.deviceId, id], [d.commandKey, 'request', randomUUID(), id], [d.commandKey, 'request', d.deviceId, randomUUID()]])
    await assert.rejects(unseal(encrypted.descriptor, encrypted.chunks, secret, purpose, target, job));
  await assert.rejects(unseal(encrypted.descriptor, [...encrypted.chunks].reverse(), d.commandKey, 'request', d.deviceId, id));
});
test('plan validation rejects tampered files, traversal, duplicate steps and invalid intervals', async () => {
  const b = bundle([step('upload', { file: 'input', remoteName: 'input' })]); b.files.input = { size: 1, sha256: '0'.repeat(64), data: 'YQ==' };
  await assert.rejects(validateBundle(b));
  const duplicate = step(); await assert.rejects(validateBundle(bundle([duplicate, duplicate])));
  for (const name of ['../x', 'a/b', 'a\\b', 'a\n', 'NUL', 'COM1.txt', 'x:', 'x.']) assert.throws(() => filename(name));
  for (const value of [0, -1, 1441, 1.5, '5', NaN, true]) assert.throws(() => intervalMinutes(value));
  assert.equal(intervalMinutes(1), 1); assert.equal(intervalMinutes(1440), 1440);
  assert.throws(() => validateRequest({ version: 1, deviceId: 'a', jobId: 'b', createdAt: new Date(Date.now()-2000).toISOString(), expiresAt: new Date(Date.now()-1000).toISOString() }, 'a', 'b'), /expired/);
});
test('file transfer and commands run in order; collision/failure stops later steps', async t => {
  const p = await fixture(t), data = Buffer.from('hello'), b = bundle([step('upload', { file: 'source', remoteName: 'input.txt' }), step(), step('download', { remoteName: 'output.txt' })]);
  b.files.source = { size: data.length, data: bytes64(data), sha256: await sha256(data) };
  const order = [];
  const result = await executeBundle(b, p.root, { checkpoint: async n => order.push(n), execute: async () => {
    assert.equal(await readFile(path.join(p.root, 'input.txt'), 'utf8'), 'hello'); await writeFile(path.join(p.root, 'output.txt'), 'done'); return { kind: 'command', exit: 0 };
  } });
  assert.deepEqual(order, [0, 1, 2]); assert.equal(result.status, 'succeeded'); assert.equal(result.steps[2].data, bytes64(Buffer.from('done')));
  let ran = false; const collision = await executeBundle(b, p.root, { execute: async () => { ran = true; } });
  assert.equal(collision.status, 'failed'); assert.equal(ran, false); assert.equal(await readFile(path.join(p.root, 'input.txt'), 'utf8'), 'hello');
  const failed = await executeBundle(bundle([step(), step()]), p.root, { execute: async () => ({ kind: 'command', exit: 7 }) }); assert.equal(failed.steps.length, 1);
});
test('real shell output, timeout, cancellation and symlink protection', async t => {
  const p = await fixture(t);
  const result = await commandStep(step('command', { command: 'echo fleet-test', timeout: 5 }), p.root); assert.equal(result.exit, 0); assert.match(result.output, /fleet-test/);
  const quoted = await commandStep(step('command', { command: 'node -e "console.log(6 * 7)"', timeout: 5 }), p.root);
  assert.equal(quoted.exit, 0, quoted.output); assert.match(quoted.output, /42/);
  const timed = await commandStep(step('command', { command: 'node -e "setTimeout(()=>{},10000)"', timeout: 1 }), p.root); assert.equal(timed.error, 'Command timed out');
  const abort = new AbortController(); abort.abort(); await assert.rejects(commandStep(step(), p.root, abort.signal));
  if (process.platform !== 'win32') {
    await writeFile(path.join(p.directory, 'outside'), 'private'); await symlink(path.join(p.directory, 'outside'), path.join(p.root, 'link'));
    const r = await executeBundle(bundle([step('download', { remoteName: 'link' })]), p.root); assert.equal(r.status, 'failed');
  }
});
test('queue acceptance is distinct from execution; receipt retries never replay commands', async t => {
  const p = await fixture(t), cloud = new MemoryCloud(); let calls = 0;
  const queued = await submit(cloud, p, bundle()); assert.equal(queued.executed, false);
  assert.equal((await readResult(cloud, p, queued.jobId)).authenticated, false);
  cloud.failReceipt = true;
  await assert.rejects(processJob(cloud, p, await cloud.lookup('job-' + queued.jobId), { execute: async () => { calls++; return { kind: 'command', exit: 0, output: 'ran' }; } }), /Connection lost/);
  const result = await processJob(cloud, p, await cloud.lookup('job-' + queued.jobId), { execute: async () => { calls++; } });
  assert.equal(result.status, 'succeeded'); assert.equal(calls, 1);
  const receipt = await readResult(cloud, p, queued.jobId); assert.equal(receipt.authenticated, true); assert.equal(receipt.steps[0].output, 'ran');
  await processJob(cloud, p, await cloud.lookup('job-' + queued.jobId), { execute: async () => { calls++; } }); assert.equal(calls, 1);
});
test('an interrupted journal is reported, never resumed; corrupt ciphertext cannot execute', async t => {
  const p = await fixture(t), cloud = new MemoryCloud(), queued = await submit(cloud, p, bundle());
  await durableJSON(path.join(p.directory, 'journal', queued.jobId + '.json'), { version: 1, jobId: queued.jobId, deviceId: p.deviceId, status: 'running', steps: [], startedAt: new Date().toISOString() });
  let calls = 0; await processJob(cloud, p, await cloud.lookup('job-' + queued.jobId), { execute: async () => { calls++; } });
  assert.equal(calls, 0); assert.equal((await readResult(cloud, p, queued.jobId)).status, 'interrupted');
  const other = await submit(cloud, p, bundle()); const r = await cloud.lookup('job-' + other.jobId); r.fields.requestJSON.value = '{}';
  await assert.rejects(processJob(cloud, p, r, { execute: async () => { calls++; } })); assert.equal(calls, 0);
});
test('expired authenticated requests receive a terminal receipt without running', async t => {
  const p = await fixture(t), cloud = new MemoryCloud();
  const queued = await submit(cloud, p, bundle(), { now: Date.now() - 7200000, expiresHours: 1 });
  let calls = 0;
  const result = await processJob(cloud, p, await cloud.lookup('job-' + queued.jobId), { execute: async () => { calls++; } });
  assert.equal(result.status, 'expired'); assert.equal(calls, 0);
  assert.equal((await readResult(cloud, p, queued.jobId)).error, 'Job expired');
});
