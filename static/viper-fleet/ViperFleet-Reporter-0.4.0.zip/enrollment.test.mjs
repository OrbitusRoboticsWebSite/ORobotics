import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync } from 'node:crypto';
import { mkdtemp, writeFile, readFile, rm, realpath, unlink, stat, mkdir } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAuthority, sealEnrollment, openEnrollment, discoverEnrollments } from './enrollment-format.mjs';
import { autoEnroll, validateBootstrap } from './auto-enroll.mjs';
import { validateReport } from './cloudkit.mjs';
import { makeBootstrap } from './make-bootstrap.mjs';

const fleet = { container: 'iCloud.orbitusrobotics.ViperFleet', environment: 'development' };
const device = () => ({ deviceId: crypto.randomUUID(), name: 'Managed Windows', commandKey: Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64') });
test('administrator bootstrap separates secrets and preserves existing machines', async () => {
  const folder = await realpath(await mkdtemp(path.join(os.tmpdir(), 'viper-bootstrap-')));
  try {
    const transport = generateKeyPairSync('ec', { namedCurve: 'prime256v1' }).privateKey.export({ type: 'pkcs8', format: 'pem' });
    const reporter = path.join(folder, 'reporter.json');
    await writeFile(path.join(folder, 'private.pem'), transport, { mode: 0o600 });
    await writeFile(reporter, JSON.stringify({ ...fleet, keyID: 'TEST', deviceId: crypto.randomUUID(), privateKeyFile: 'private.pem' }), { mode: 0o600 });
    const existing = device(), controller = path.join(folder, 'existing.json');
    await writeFile(controller, JSON.stringify({ version: 1, ...fleet, keyID: 'TEST', privateKeyPEM: transport, devices: [existing] }), { mode: 0o600 });
    const directory = path.join(folder, 'first');
    await makeBootstrap({ reporter, controller, directory, minutes: 7 });
    const read = name => readFile(path.join(directory, name), 'utf8').then(JSON.parse);
    const bootstrap = await read('bootstrap.json'), full = await read('controller.json'), keys = await read('command-keys.json');
    assert.equal(bootstrap.enrollmentAuthority.privateKey, undefined);
    assert.equal(bootstrap.intervalMinutes, 7); assert.equal(keys.privateKeyPEM, undefined);
    assert.deepEqual(full.devices, [existing]); assert.deepEqual(keys.enrollmentAuthority, full.enrollmentAuthority);
    await makeBootstrap({ reporter, controller: path.join(directory, 'controller.json'), directory: path.join(folder, 'second') });
    assert.deepEqual(JSON.parse(await readFile(path.join(folder, 'second/controller.json'))).enrollmentAuthority, full.enrollmentAuthority);
    await assert.rejects(makeBootstrap({ reporter, directory }));
    if (process.platform !== 'win32') assert.equal((await stat(path.join(directory, 'bootstrap.json'))).mode & 0o077, 0);
    await mkdir(path.join(folder, '.git'));
    await assert.rejects(makeBootstrap({ reporter, directory: path.join(folder, 'unsafe') }), /outside Git/);
  } finally { await rm(folder, { recursive: true, force: true }); }
});
test('controller-only enrollment encryption binds fleet, machine, name and authority', async () => {
  const authority = await createAuthority(), { privateKey, ...pub } = authority, d = device();
  const report = { deviceId: d.deviceId, hostLabel: d.name, enrollment: await sealEnrollment(d, pub, fleet) };
  assert.deepEqual(await openEnrollment(report, authority, fleet), d);
  assert.equal(JSON.stringify(report).includes(d.commandKey), false);
  await assert.rejects(openEnrollment(report, pub, fleet));
  await assert.rejects(openEnrollment(report, await createAuthority(), fleet));
  await assert.rejects(openEnrollment({ ...report, deviceId: crypto.randomUUID() }, authority, fleet));
  await assert.rejects(openEnrollment({ ...report, hostLabel: 'Another machine' }, authority, fleet));
  await assert.rejects(openEnrollment(report, authority, { ...fleet, environment: 'production' }));
  const tampered = structuredClone(report); tampered.enrollment.sealed = 'A' + tampered.enrollment.sealed.slice(1);
  if (tampered.enrollment.sealed === report.enrollment.sealed) tampered.enrollment.sealed = 'B' + tampered.enrollment.sealed.slice(1);
  await assert.rejects(openEnrollment(tampered, authority, fleet));
  assert.deepEqual(await discoverEnrollments([report], authority, fleet, [d]), [d]);
  await assert.rejects(discoverEnrollments([report], authority, fleet, [{ ...d, commandKey: device().commandKey }]), /different command key/);
});
test('private bootstrap creates unique machines and repeat installs preserve identity and disabled state', async () => {
  const folder = await realpath(await mkdtemp(path.join(os.tmpdir(), 'viper-enrollment-')));
  try {
    const authority = await createAuthority(), { privateKey, ...pub } = authority;
    const transport = generateKeyPairSync('ec', { namedCurve: 'prime256v1' }).privateKey.export({ type: 'pkcs8', format: 'pem' });
    const bootstrap = { version: 1, kind: 'viperlink-auto-enrollment', ...fleet, keyID: 'TEST', privateKeyPEM: transport, intervalMinutes: 5, enrollmentAuthority: pub };
    const bootstrapFile = path.join(folder, 'bootstrap.json');
    await writeFile(bootstrapFile, JSON.stringify(bootstrap), { mode: 0o600 });
    assert.throws(() => validateBootstrap({ ...bootstrap, enrollmentAuthority: authority }), /must not contain/);
    const first = await autoEnroll({ bootstrapFile, data: path.join(folder, 'first') });
    const second = await autoEnroll({ bootstrapFile, data: path.join(folder, 'second') });
    assert.notEqual(first.deviceId, second.deviceId); assert.equal(first.enabled, true);
    const profileFile = path.join(folder, 'first', 'receiver.json');
    const p = JSON.parse(await readFile(profileFile, 'utf8'));
    const report = { schemaVersion: 1, deviceId: p.deviceId, hostLabel: p.name, os: { family: 'windows', flavor: 'Windows', version: 'test', architecture: 'x64' },
      agentVersion: '0.4.0', reportedAt: new Date().toISOString(), health: 'unknown', summary: { installedApps: 0, potentialVulnerabilities: 0 }, tags: [], enrollment: p.enrollment };
    assert.deepEqual(await openEnrollment(validateReport(report, p.deviceId), authority, fleet), { deviceId: p.deviceId, name: p.name, commandKey: p.commandKey });
    p.enabled = false; await writeFile(profileFile, JSON.stringify(p), { mode: 0o600 });
    const before = await readFile(profileFile);
    const repeat = await autoEnroll({ bootstrapFile, data: path.join(folder, 'first') });
    assert.equal(repeat.reused, true); assert.equal(repeat.deviceId, first.deviceId); assert.equal(repeat.enabled, false);
    assert.deepEqual(await readFile(profileFile), before);
    await unlink(path.join(folder, 'first', 'fleet-private.pem'));
    await assert.rejects(autoEnroll({ bootstrapFile, data: path.join(folder, 'first') }));
    assert.deepEqual(await readFile(profileFile), before, 'broken existing enrollment must not be replaced');
  } finally { await rm(folder, { recursive: true, force: true }); }
});
