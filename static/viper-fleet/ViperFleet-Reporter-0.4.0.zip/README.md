# Viper Fleet: direct CloudKit reporting

Version 0.3 also includes opt-in queued ViperLink payloads and configurable
RedAgent check-ins. See [COMMANDS.md](COMMANDS.md) for enrollment, native/web
submission, execution receipts, limits and the per-machine key model. The
`report-direct.mjs` command below remains status-only.

Viper Fleet sends status JSON directly from a managed Mac, Windows PC or Linux
machine to Apple's CloudKit Web Services. No Cloudflare Worker, relay, separate
hosting account or Apple login on the reporting machine is required. The
unlisted administrator portal stays on GitHub Pages:
https://www.orbitusrobotics.com/viper-fleet/

The dedicated container is **`iCloud.orbitusrobotics.ViperFleet`**, registered in
the existing Apple developer team. Version 0.2 replaces the staged Worker and
bearer-token design; that older implementation is recoverable in Git history.
No Cloudflare service was deployed.

## Access model

```text
Trusted managed machine -- signed HTTPS JSON --> Apple CloudKit
                                                    ^
Administrator -- Apple-hosted sign-in + FleetAdmin --|

GitHub Pages serves the portal and public reporter source only.
```

CloudKit allows multiple server-to-server keys on a container. Dedicate one
P-256 key to fleet reporting and distribute it privately to the intended
machines. **It is not a write-only or per-device credential.** Each holder can
use it to read, modify or delete every `ViperFleetStatus` report through
the key owner's FleetReporter role in this container's public database. Giving a machine a different device ID does not restrict its key.
Local schema/size checks and timestamp/concurrency guards help cooperating
clients; a holder can bypass them with another CloudKit client.

The separate container limits the data exposed by this shared-key design. It
does not grant access to personal iCloud Drive, other containers or CloudKit
private databases. Use trusted managed devices only. Revoking this shared key
stops every reporter using it; individual removal requires separate keys or a
change to the authentication design. Never put the private key in the portal,
Git, a public app/download, URLs, command arguments or logs.

The schema grants `FleetAdmin` read access to `ViperFleetStatus` and gives `FleetReporter` create/read/write
access. Assign FleetReporter only to the registered key owner. The schema grants nothing to World, Authenticated or Creator. Server keys inherit their creator's
roles; they do not bypass record permissions. A registered key alone cannot
write until its owner receives FleetReporter in the selected environment. The website API token is public configuration; Apple sign-in and the
CloudKit role protect the records. A hidden URL and `noindex` do not provide
access control. This is the container's **public database scope with restricted
record permissions**, not the owner's personal private database.

## Prepare the dedicated key

Requires Node.js 22 or later. There are no npm dependencies. From this directory:

```sh
node setup-direct.mjs /absolute/private/new-fleet-directory
```

The command refuses an existing destination or a directory inside a Git
checkout. It creates a private directory, P-256 PKCS#8 private key, public key,
reporter profile and clearly invented example report. On Unix, the directory
is mode 700 and files mode 600. On Windows, restrict the folder ACL to its
reporting account; Unix permission bits do not implement Windows ACLs.

In CloudKit Console, select `iCloud.orbitusrobotics.ViperFleet` and open
**Tokens & Keys → Server-to-Server Keys**. Register **fleet-public.pem only**,
with a name such as `Viper Fleet Direct Reporting`. Copy Apple's returned key
ID into the private `reporter-profile.json`. Keep `fleet-private.pem` local and
retain a secure backup. Never upload the private key to Apple or the website.

Example profile (contains no real credential):

```json
{
  "container": "iCloud.orbitusrobotics.ViperFleet",
  "environment": "development",
  "keyID": "REPLACE_WITH_REGISTERED_KEY_ID",
  "deviceId": "00000000-0000-4000-8000-000000000001",
  "privateKeyFile": "fleet-private.pem"
}
```

For another trusted machine, securely provision the shared private key and a
profile with its own UUID v4. Relative key paths are resolved beside the
profile. Do not run `setup-direct.mjs` separately expecting an unregistered new
key to authenticate. Additional keys can be registered when separate
revocation is needed; Apple does not document a numeric key limit in the
referenced web-services guide.

## Configure CloudKit and the owner portal

1. Validate/import `schema.ckdb` into this new container's development
   environment. Do not import it over another application's schema.
2. Create a browser API token restricted to `https://www.orbitusrobotics.com`.
   It is distinct from the server key. Add a local origin only for deliberate
   local testing, then remove that origin when no longer needed.
3. Establish the owner's container identity with Apple's sign-in flow and
   assign that verified account the custom `FleetAdmin` role. Assign the
   registered server-key owner `FleetReporter` to enable signed writes. Use
   `users/caller` with the server signature to verify that owner identity. Do not grant
   fleet read access to every authenticated Apple account.
4. Test a synthetic report, read it back, and confirm anonymous and unrelated
   signed-in users cannot read the record. Check the owner can read. A passing
   local test does not prove live CloudKit authorization.
5. Deploy the validated schema to production, verify production permissions,
   then explicitly select `production` in reporter profiles. Keep development
   and production enrollment deliberate; use separate keys if needed.
6. Enable the portal using the Actions configuration documented in the website
   repository's `docs/viper-fleet.md`. The source configuration remains disabled
   until activation is complete. Turning off the website does not revoke keys.

## Send a status report

Create a JSON file with your intended status fields. It need not contain
`deviceId` or `reportedAt`; the reporter supplies these from the profile and
current UTC clock. If supplied explicitly, they are validated rather than
silently replaced. The reporter does not enumerate applications, collect host
information, read private files, execute commands or schedule itself.

```json
{
  "schemaVersion": 1,
  "hostLabel": "Example workstation",
  "os": { "family": "macos", "flavor": "macOS", "version": "26.0", "architecture": "arm64" },
  "agentVersion": "0.2.0",
  "health": "unknown",
  "summary": { "installedApps": 42, "potentialVulnerabilities": 0 },
  "tags": ["example"]
}
```

Use `macos`, `windows` or `linux` for `os.family`; `flavor` and `version` preserve
OS editions and distributions. Health is `ok`, `attention` or `unknown` and is
self-reported, not an attestation. Replace invented example values before
sending real status.

```sh
# Validate credentials and payload locally; sends nothing.
node report-direct.mjs --profile /private/reporter-profile.json --report status.json --validate

# Sign and send directly to Apple's fixed HTTPS API origin.
node report-direct.mjs --profile /private/reporter-profile.json --report status.json
```

Quote paths with spaces. On Windows use the corresponding `C:\private\...`
paths. The client requires private file permissions on macOS/Linux, does not
follow redirects and times out requests after 15 seconds. It signs the exact
JSON body hash, path and UTC date using ECDSA SHA-256 in ASN.1 DER format.
Keep the host clock synchronized.

There is one latest record per device (`device-<UUID>`). Updates use CloudKit's
`recordChangeTag` to avoid overwriting concurrent changes and reject duplicate
or older reported timestamps. An HTTP success alone is insufficient: the
client checks the returned record, change tag and Apple-assigned modification
timestamp. Only then does it print `accepted: true` with `receivedAt`.
The portal sorts and displays this server time, not a client-supplied receipt.
If a request times out, the write may still have reached Apple; check the record
or retry with a fresh status. No automatic retry loop or always-running agent
is installed.

## Validation and operational state

```sh
node --test direct.test.mjs
```

Tests cover signature verification and tampering, Apple-only request routing,
server receipts, concurrency, rejected/invalid reports, key format, private
file permissions, local-only validation and safe key preparation. CI runs on
macOS, Windows and Linux; mocks do not prove a real Windows/Linux host reported
to Apple. The portal tests separately cover filters, pagination, permission
failure and Apple server timestamps.

The development container is registered. Apple imported the schema, the user
registered the dedicated key, and the verified key owner received FleetAdmin
and FleetReporter after approval. Signed synthetic creation, update, read-back
and sorting passed against Apple. Anonymous querying returned ACCESS_DENIED;
anonymous lookup hid the existing record as NOT_FOUND. No corporate machine
inventory was collected or uploaded. The website sign-in is a development
pilot; production and an unrelated signed-in account still need separate checks.

## Apple references

- [Server-to-server keys, revocation and request signing](https://developer.apple.com/library/archive/documentation/DataManagement/Conceptual/CloudKitWebServicesReference/SettingUpWebServices.html)
- [CloudKit Catalog and server-key privileges](https://developer.apple.com/go/?id=cloudkit-catalog)
- [Schema fields and custom security roles](https://developer.apple.com/documentation/cloudkit/integrating-a-text-based-schema-into-your-workflow)
- [Record metadata and timestamps](https://developer.apple.com/library/archive/documentation/DataManagement/Conceptual/CloudKitWebServicesReference/Types.html)
- [Queries and system-field sorting](https://developer.apple.com/library/archive/documentation/DataManagement/Conceptual/CloudKitWebServicesReference/QueryingRecords.html)
