#!/usr/bin/env node
// Administrator-side tool: creates a private, reusable receiver bootstrap and
// matching controller imports. Never publish its output on a public website.
import { mkdir, writeFile, lstat, realpath } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { loadProfile } from './report-direct.mjs';
import { privateJSON } from './queue-agent.mjs';
import { check, intervalMinutes } from './queue-format.mjs';
import { createAuthority, validateAuthority } from './enrollment-format.mjs';

export async function makeBootstrap({ reporter, directory, controller, minutes = 5 }) {
  intervalMinutes(minutes); check(path.isAbsolute(directory), 'Use an absolute private output directory');
  const parent = await realpath(path.dirname(directory));
  directory = path.join(parent, path.basename(directory));
  for (let p = parent; ; p = path.dirname(p)) {
    try { await lstat(path.join(p, '.git')); throw new Error('Keep private bootstrap files outside Git'); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
    if (path.dirname(p) === p) break;
  }
  const credentials = await loadProfile(path.resolve(reporter));
  const old = controller ? await privateJSON(path.resolve(controller), 1048576) : null;
  if (old) check(old.container === credentials.container && old.environment === credentials.environment
    && old.keyID === credentials.keyID && Array.isArray(old.devices), 'Controller and reporter must belong to the same fleet');
  const authority = old?.enrollmentAuthority ? validateAuthority(old.enrollmentAuthority, true) : await createAuthority();
  const { privateKey, ...publicAuthority } = authority;
  const common = { container: credentials.container, environment: credentials.environment, keyID: credentials.keyID };
  await mkdir(directory, { mode: 0o700 });
  const outputs = {
    'bootstrap.json': { version: 1, kind: 'viperlink-auto-enrollment', ...common,
      privateKeyPEM: credentials.privateKey, intervalMinutes: minutes, enrollmentAuthority: publicAuthority },
    'controller.json': { version: 1, ...common, privateKeyPEM: credentials.privateKey,
      devices: old?.devices || [], enrollmentAuthority: authority },
    'command-keys.json': { version: 1, container: common.container, environment: common.environment,
      devices: old?.devices || [], enrollmentAuthority: authority },
  };
  for (const [name, value] of Object.entries(outputs)) await writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + '\n', { mode: 0o600, flag: 'wx' });
  return { prepared: true, directory, authorityId: authority.id, existingDevices: old?.devices.length || 0, intervalMinutes: minutes };
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2), options = {};
    for (let i = 0; i < args.length; i += 2) {
      check(['--reporter', '--directory', '--controller', '--minutes'].includes(args[i]) && args[i + 1] && !options[args[i]], 'Invalid bootstrap arguments');
      options[args[i]] = args[i + 1];
    }
    console.log(JSON.stringify(await makeBootstrap({ reporter: options['--reporter'], directory: options['--directory'],
      controller: options['--controller'], minutes: Number(options['--minutes'] || 5) })));
  } catch { console.error('Unable to create private enrollment bootstrap. Check protected input files and use a new output directory outside Git.'); process.exitCode = 1; }
}
