import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, createHash, verify, createPublicKey } from 'node:crypto';
import { mkdtemp, readFile, writeFile, chmod, mkdir, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { cloudKitHeaders, saveReport, validateReport, validateCredentials, containerIdentifier } from './cloudkit.mjs';
import { run } from './report-direct.mjs';
import { setup } from './setup-direct.mjs';
const now = Date.parse('2026-11-11T05:00:00Z');
const deviceId = '00000000-0000-4000-8000-000000000001';
const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
const credentials = { container: containerIdentifier, environment: 'development', keyID: 'test-key', deviceId,
  privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
function report(overrides = {}) { return { schemaVersion: 1, deviceId, hostLabel: 'Invented machine',
  os: { family: 'linux', flavor: 'Debian', version: '13', architecture: 'x86_64' }, agentVersion: '0.2.0',
  reportedAt: new Date(now).toISOString(), health: 'unknown', summary: { installedApps: 3, potentialVulnerabilities: 0 }, tags: ['test'], ...overrides }; }
function storage({ existing, failure, acknowledged = true } = {}) {
  const calls = [];
  return { calls, fetcher: async (url, options) => {
    calls.push({ url, ...options }); const body = JSON.parse(options.body);
    if (url.endsWith('/lookup')) return Response.json({ records: [existing || { recordName: `device-${deviceId}`, serverErrorCode: 'NOT_FOUND' }] });
    if (failure) return Response.json({ records: [{ serverErrorCode: failure, reason: 'private provider detail' }] });
    return Response.json({ records: [{ recordName: body.operations[0].record.recordName, recordChangeTag: 'new-tag',
      ...(acknowledged ? { modified: { timestamp: now + 250 } } : {}) }] });
  } };
}
test('signs exact bytes, date and path using CloudKit ECDSA DER format', () => {
  const body = '{"records":[]}', requestPath = `/database/1/${containerIdentifier}/development/public/records/lookup`;
  const headers = cloudKitHeaders(body, requestPath, credentials, now);
  const message = `${headers['X-Apple-CloudKit-Request-ISO8601Date']}:${createHash('sha256').update(body).digest('base64')}:${requestPath}`;
  const signature = Buffer.from(headers['X-Apple-CloudKit-Request-SignatureV1'], 'base64');
  assert.equal(signature[0], 0x30);
  assert.ok(verify('sha256', Buffer.from(message), publicKey, signature));
  assert.equal(verify('sha256', Buffer.from(message + 'tampered'), publicKey, signature), false);
  assert.equal(headers['X-Apple-CloudKit-Request-ISO8601Date'], '2026-11-11T05:00:00Z');
});
test('direct reporting uses Apple only and acknowledges the Apple server timestamp', async () => {
  const mock = storage(), receipt = await saveReport(report(), credentials, { now, fetcher: mock.fetcher });
  assert.equal(receipt.accepted, true); assert.equal(receipt.receivedAt, new Date(now + 250).toISOString());
  assert.equal(mock.calls.length, 2);
  for (const call of mock.calls) {
    assert.equal(new URL(call.url).origin, 'https://api.apple-cloudkit.com');
    assert.equal(call.redirect, 'error'); assert.ok(call.signal);
    assert.doesNotMatch(call.body, /PRIVATE KEY/);
  }
  const op = JSON.parse(mock.calls[1].body).operations[0];
  assert.equal(op.operationType, 'create'); assert.equal(op.record.recordName, `device-${deviceId}`);
  assert.equal(op.record.fields.receivedAt, undefined); assert.equal(op.record.modified, undefined);
});
test('updates use recordChangeTag; duplicate and older reports do not overwrite', async () => {
  for (const age of [60000, 0, -1000]) {
    const mock = storage({ existing: { recordName: `device-${deviceId}`, recordChangeTag: 'old-tag',
      fields: { payloadJSON: { value: JSON.stringify(report({ reportedAt: new Date(now - age).toISOString() })) } } } });
    if (age > 0) {
      await saveReport(report(), credentials, { now, fetcher: mock.fetcher });
      const op = JSON.parse(mock.calls[1].body).operations[0]; assert.equal(op.operationType, 'update'); assert.equal(op.record.recordChangeTag, 'old-tag');
    } else { await assert.rejects(saveReport(report(), credentials, { now, fetcher: mock.fetcher }), /already stored/); assert.equal(mock.calls.length, 1); }
  }
});
test('conflicts, missing acknowledgements, auth failures and network failures never claim acceptance', async () => {
  for (const options of [{ failure: 'CONFLICT' }, { failure: 'EXISTS' }, { failure: 'ACCESS_DENIED' }, { acknowledged: false }]) {
    await assert.rejects(saveReport(report(), credentials, { now, fetcher: storage(options).fetcher }), error => !error.message.includes('private provider detail'));
  }
  await assert.rejects(saveReport(report(), credentials, { now, fetcher: async () => new Response('', { status: 401 }) }), /HTTP 401/);
  await assert.rejects(saveReport(report(), credentials, { now, fetcher: async () => { throw new Error('private detail'); } }), /no successful receipt/);
});
test('bounds reports, rejects commands, and validates macOS, Windows and Linux', async () => {
  for (const family of ['macos', 'windows', 'linux']) {
    const r = report(); r.os.family = family; r.tags = ['test', 'test']; assert.deepEqual(validateReport(r, deviceId, now).tags, ['test']);
  }
  for (const invalid of [report({ commands: ['whoami'] }), report({ hostLabel: 'a'.repeat(81) }), report({ hostLabel: 'line\nbreak' }),
    report({ hostLabel: 'x'.repeat(8193) }), report({ deviceId: 'bad' }), report({ reportedAt: '2020-01-01T00:00:00Z' }),
    report({ tags: Array(9).fill('x') }), report({ health: 'secure' }), report({ summary: { installedApps: -1, potentialVulnerabilities: 0 } })]) {
    const mock = storage(); await assert.rejects(saveReport(invalid, credentials, { now, fetcher: mock.fetcher })); assert.equal(mock.calls.length, 0);
  }
});
test('rejects missing or malformed keys, environment and container before networking', () => {
  const wrongCurve = generateKeyPairSync('ec', { namedCurve: 'secp384r1' }).privateKey.export({ type: 'pkcs8', format: 'pem' });
  for (const change of [{ container: 'iCloud.example/../../other' }, { environment: 'other' }, { keyID: '' }, { privateKey: '' }, { privateKey: wrongCurve }])
    assert.throws(() => validateCredentials({ ...credentials, ...change }));
});
test('local setup protects keys, refuses overwrite and keeps credentials outside Git', async t => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'viper-fleet-')); t.after(() => rm(root, { recursive: true, force: true }));
  const directory = await setup(path.join(root, 'private'));
  const profileFile = path.join(directory, 'reporter-profile.json');
  const profile = JSON.parse(await readFile(profileFile, 'utf8'));
  assert.equal(profile.container, containerIdentifier); assert.equal(profile.keyID, '');
  const localPrivate = await readFile(path.join(directory, 'fleet-private.pem'), 'utf8');
  assert.equal(createPublicKey(localPrivate).export({ type: 'spki', format: 'pem' }), await readFile(path.join(directory, 'fleet-public.pem'), 'utf8'));
  await assert.rejects(setup(directory));
  await mkdir(path.join(root, '.git')); await assert.rejects(setup(path.join(root, 'in-repo')), /outside Git/);
  profile.keyID = 'test-key'; await writeFile(profileFile, JSON.stringify(profile));
  const args = ['--profile', profileFile, '--report', path.join(directory, 'example-status.json')];
  let calls = 0;
  const checked = await run([...args, '--validate'], { now, fetcher: () => { calls++; throw new Error(); } });
  assert.equal(checked.validated, true); assert.equal(checked.sent, false); assert.equal(calls, 0);
  const mock = storage(); const receipt = await run(args, { now, fetcher: mock.fetcher });
  assert.equal(receipt.deviceId, profile.deviceId); assert.equal(receipt.accepted, true);
  if (process.platform !== 'win32') {
    await chmod(path.join(directory, 'fleet-private.pem'), 0o644);
    await assert.rejects(run([...args, '--validate'], { now }), /chmod 600/);
  }
  await assert.rejects(run([...args, '--extra'], { now }), /Usage/);
});
