#!/usr/bin/env node
// Local preparation only. Register the PUBLIC key with Apple before reporting.
import { generateKeyPairSync, randomUUID } from 'node:crypto';
import { mkdir, writeFile, realpath, access } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { containerIdentifier } from './cloudkit.mjs';

export async function setup(directory) {
  if (!directory || !path.isAbsolute(directory)) throw new Error('Use an absolute path to a new private directory outside Git');
  const parent = await realpath(path.dirname(directory));
  for (let current = parent; ; current = path.dirname(current)) {
    let inGit = false; try { await access(path.join(current, '.git')); inGit = true; } catch {}
    if (inGit) throw new Error('Keep signing keys outside Git repositories');
    if (path.dirname(current) === current) break;
  }
  const destination = path.join(parent, path.basename(directory));
  await mkdir(destination, { mode: 0o700 }); // Never overwrite an existing key.
  const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const write = (name, value) => writeFile(path.join(destination, name), value, { mode: 0o600, flag: 'wx' });
  await write('fleet-private.pem', privateKey.export({ type: 'pkcs8', format: 'pem' }));
  await write('fleet-public.pem', publicKey.export({ type: 'spki', format: 'pem' }));
  await write('reporter-profile.json', JSON.stringify({ container: containerIdentifier, environment: 'development',
    keyID: '', deviceId: randomUUID(), privateKeyFile: 'fleet-private.pem' }, null, 2) + '\n');
  await write('example-status.json', JSON.stringify({ schemaVersion: 1, hostLabel: 'Invented fleet setup check',
    os: { family: 'macos', flavor: 'macOS', version: 'example', architecture: 'arm64' }, agentVersion: '0.2.0',
    health: 'unknown', summary: { installedApps: 0, potentialVulnerabilities: 0 }, tags: ['synthetic-test'] }, null, 2) + '\n');
  return destination;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try { console.log(`Prepared ${await setup(process.argv[2])}. Register fleet-public.pem only; the private key has not been uploaded or activated.`); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
