# Musimotion MCP companion

Connect a desktop AI assistant to Musimotion’s AI Creation Studio. Give the assistant a brief in ordinary language. Its model can author titles, timed graphic layers and instrumental scores with original bass and lead motifs. The companion saves a new scene draft that you can review and edit on Mac, iPad or Vision Pro.

## Connect a desktop assistant

1. Install Node.js 22 or later on the computer running your MCP host. Put this companion in a folder you intend to keep. From a terminal in that folder, install its dependencies once.

   ```sh
   npm ci --omit=dev
   ```

2. Get the absolute paths to the Node executable and this copy of the companion. The following command works in macOS Terminal and Windows PowerShell.

   ```sh
   node -e "console.log(process.execPath); console.log(require('node:path').resolve('server.mjs'))"
   ```

3. In your assistant’s local MCP server settings, add a **stdio** server named **musimotion**. Set its **command** to the first path, and its first **argument** to the second path. A host that accepts JSON configuration can use the following structure. Replace both sample paths. On Windows, write each backslash as `\\` inside JSON strings, or use forward slashes.

   ```json
   {
     "mcpServers": {
       "musimotion": {
         "command": "/absolute/path/to/node",
         "args": ["/absolute/path/to/musimotion-mcp/server.mjs"]
       }
     }
   }
   ```

   For Codex CLI, register the same executable and argument with `codex mcp add musimotion -- "/absolute/path/to/node" "/absolute/path/to/musimotion-mcp/server.mjs"`. Start a new client session or reconnect the server. Look for **prepare_scene_brief**, **create_scene_plan** and **create_music_score** in the host’s available tools.

4. Drafts are written under **Downloads → Musimotion AI** in the home folder of the account running the companion. To choose another location, add two more arguments after the script path, `--output-dir` and the absolute path of the folder. The companion creates that folder when it saves the first draft.

An MCP host that runs locally and can launch subprocesses is required. macOS and Windows path examples describe the computer hosting the assistant. iPad and Vision Pro receive the resulting file using Files, AirDrop or your usual file transfer.

## Make and use a scene

1. In the connected assistant, try this brief:

   > Use Musimotion to create an eight-second Lantern Festival opening with the headline “Lanterns at Dusk”. Make a gold star rise and settle from 2 to 6 seconds against a dark sky.

2. The assistant can use **prepare_scene_brief** to review a request. For a brief like “make an intro”, it receives a question about the subject. If two instructions conflict, the assistant can supply one tailored question and suggested answers. Give your answer in the host conversation. A specific brief can go directly to **create_scene_plan**.
3. **create_scene_plan** returns the file location and the exact draft JSON. Filenames end in `.musiplan.json`. Each call creates a separate file. This guide includes a [Lantern Festival draft](examples/lantern-festival.musiplan.json) produced by the tool.
4. In Musimotion, open **AI Creation Studio → Import AI Draft… → Choose JSON File…**. To paste instead, copy just the JSON object with `version`, `presentationTitle`, `headline` and `duration` at its top level into **Draft JSON** and choose **Review Draft**.
5. Inspect the copy, duration and timed cues. Choose **Add Scene** to insert the scene in the current project. Open its objects to edit the named star layer. Choose **Undo** to reverse insertion.

A single draft supports a 5–120 second scene with up to eight timed text or shape layers. Each cue places its center within the canvas and specifies a motion and a start and end fraction. An eight-second scene runs a cue from 0.25 to 0.75 at 2–6 seconds. A visual description can be included for later artwork generation in the app. Ask the host for another draft to add a second scene.

## Compose a score

Ask the connected assistant to write an instrumental. For example:

> Compose eight seconds of melodic techno for the lantern opening. Use a D bass hook, give the kick space and let the lead answer in the last two bars.

The assistant calls **create_music_score** with a title, style, tempo, bar count, bass tonic, bass and lead scale degrees, brightness and activity. A degree of zero is the tonic and a value of −1 is a rest. The optional ensemble selects a group of instruments. The tool returns a new `.musiscore.json` file and its exact JSON. The included [Lantern Pulse score](examples/lantern-pulse.musiscore.json) uses both parts, an electronic ensemble and four bars at 120 BPM.

Open **Music Studio → Import AI Score…**, choose the JSON file and select **Preview** to hear the locally rendered instrumental. You can add the take to your scene or replace a selected audio track. Inside Rhythm Studio, **Use as Rhythm Song** applies it to the beat chart. For a finished recording from another service such as a Gemini audio-only MP3, use the artwork editor’s **Add Media** and its folder-plus import button.

## Data and troubleshooting

Your assistant’s chosen model processes the brief and its follow-up in that host. Local and cloud hosts have their own data-handling settings. The companion exchanges scene fields and the resulting local file path with the host over the child process’s standard streams. It writes in its configured output folder and uses no model credentials or network listener. It does not read your open project or Photos library. Importing a draft leaves the existing project untouched until you choose **Add Scene**.

- **The host cannot launch the server.** Recheck both absolute paths and run `npm ci --omit=dev` in the folder containing `package-lock.json`. A GUI host can have a different executable search path than a terminal.
- **The host reports a write error.** Choose an output folder the account can write to, then reconnect the server.
- **A draft is rejected.** Inspect the returned field error and ask the assistant to correct that field. Use six hex digits for a color. Set every cue’s end after its start and within the scene. If you pasted a result, use the scene JSON object by itself.
- **Run the connection checks.** For a development install, run `npm ci` followed by `npm test`. The tests start actual stdio subprocesses with the official MCP client in modern and legacy modes.

The companion uses the official TypeScript MCP SDK for discovery, schema validation and stdio connections. [MCP TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk) · [Protocol compatibility](https://modelcontextprotocol.io/specification/2026-07-28/basic/versioning)

## Perform a 3D music video

Ask for “Beat Rail Express at 128 BPM” or “Chroma Nova with psychedelic color bursts at 140 BPM.” The 1.1 companion exposes 32 design IDs in the schema for **create_scene_plan**. Set the optional **spatialMusicVideo** and **musicVideoTempo** fields. Review the draft in Musimotion, add the scene and press **Play**. Full Immersion on Vision Pro surrounds the editable performance with its photographic environment. [Train example](examples/beat-rail.musiplan.json)
