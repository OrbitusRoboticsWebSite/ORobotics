#!/usr/bin/env node
import { randomUUID } from 'node:crypto';
import { constants } from 'node:fs';
import { copyFile, link, mkdir, open, unlink } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { McpServer } from '@modelcontextprotocol/server';
import { serveStdio } from '@modelcontextprotocol/server/stdio';
import * as z from 'zod/v4';
import { fieldText, scenePlan } from './scene-plan.mjs';
import { musicScore } from './music-score.mjs';

const { values } = parseArgs({ options: { 'output-dir': { type: 'string' } } });
const outputDir = resolve(values['output-dir'] ?? join(homedir(), 'Downloads', 'Musimotion AI'));
const directions = 'Compose one editable scene using create_scene_plan. Set a headline and duration, then stage up to eight text or shape cues over time. Preserve specified copy, timing and motion. Ask the user one focused question when a missing subject or conflicting instructions would change the result. Use sensible defaults for optional choices. For a spatial music video choose spatialMusicVideo and an optional musicVideoTempo. The train design beatRailExpress sends one carriage across the signal on each beat. For an instrumental soundtrack, use create_music_score to author bass and lead motifs for Music Studio.';
const clarification = z.strictObject({
  question: fieldText(200),
  choices: z.array(fieldText(100)).min(2).max(3).optional(),
});

function reviewBrief({ brief, clarify }) {
  if (clarify) return { status: 'needs_clarification', ...clarify };
  // Catch requests with only presentation boilerplate; a host model can flag other
  // semantic ambiguities using clarify. Specific short briefs (e.g. "Lunar eclipse") pass.
  const generic = new Set('a an the i we want would like could please can you to for of with and us make create generate design build me my us our something anything it this some cool nice awesome beautiful interesting good dynamic new editable quick short long video animation animated scene presentation intro introduction outro title trailer opener clip'.split(' '));
  const words = brief.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [];
  if (words.length === 0 || words.every(word => generic.has(word))) {
    return { status: 'needs_clarification', question: 'What should the audience see or learn in this scene?' };
  }
  return { status: 'ready', guidance: directions };
}

async function exportDraft(value, title, extension) {
  const json = JSON.stringify(value, null, 2) + '\n';
  if (Buffer.byteLength(json) > 65536) throw new Error('The draft must fit in 64 KiB.');
  const slug = title.normalize('NFKC').toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '');
  const id = randomUUID();
  const fileName = `${Array.from(slug).slice(0, 36).join('') || 'draft'}-${id}.${extension}.json`;
  await mkdir(outputDir, { recursive: true, mode: 0o700 });
  const path = join(outputDir, fileName);
  const temporary = join(outputDir, `.${id}.tmp`);
  const file = await open(temporary, 'wx', 0o600);
  try {
    try {
      await file.writeFile(json);
    } finally {
      await file.close();
    }
    // The importer sees a complete file. Never replace an existing draft, including
    // on removable or shared volumes that lack hard-link support.
    try {
      await link(temporary, path);
    } catch (error) {
      if (!['ENOTSUP', 'EPERM', 'ENOSYS', 'EXDEV'].includes(error.code)) throw error;
      await copyFile(temporary, path, constants.COPYFILE_EXCL);
    }
  } finally {
    await unlink(temporary);
  }
  return { path, json, fileName };
}

function makeServer() {
  const server = new McpServer({ name: 'musimotion', version: '1.1.0' }, { instructions: directions });
  server.registerTool('prepare_scene_brief', {
    title: 'Review a Musimotion brief',
    description: 'Review the user’s creative brief. When two interpretations would materially change the result, pass one tailored question in clarify. Ask the returned question in chat and use the answer to compose the scene.',
    inputSchema: z.strictObject({ brief: fieldText(2000), clarify: clarification.optional() }),
    annotations: { readOnlyHint: true, openWorldHint: false },
  }, input => {
    const review = reviewBrief(input);
    return { content: [{ type: 'text', text: JSON.stringify(review) }], structuredContent: review };
  });
  server.registerTool('create_scene_plan', {
    title: 'Create an editable Musimotion scene',
    description: 'Write one new local .musiplan.json draft for import or paste into AI Creation Studio. The host model authors the scene and its optional timed cues. This tool returns the saved path and the exact JSON.',
    inputSchema: scenePlan,
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false },
  }, async plan => {
    const { path, json, fileName } = await exportDraft(plan, plan.presentationTitle, 'musiplan');
    return {
      content: [
        { type: 'text', text: `Saved ${path}. In AI Creation Studio, choose Import AI Draft… to open this file or paste the following JSON.` },
        { type: 'text', text: json },
      ],
      structuredContent: { fileName, filePath: path, fileUri: pathToFileURL(path).href, plan },
    };
  });
  server.registerTool('create_music_score', {
    title: 'Compose a Musimotion instrumental',
    description: 'Write one local .musiscore.json score. Author bass and lead motifs using scale degrees and rests, then choose a style, tempo, length, timbre and activity. Music Studio will render the instrumental on the user’s device.',
    inputSchema: musicScore,
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false },
  }, async score => {
    const { path, json, fileName } = await exportDraft(score, score.title, 'musiscore');
    return {
      content: [
        { type: 'text', text: `Saved ${path}. Import this file or the following score JSON in Music Studio.` },
        { type: 'text', text: json },
      ],
      structuredContent: { fileName, filePath: path, fileUri: pathToFileURL(path).href, score },
    };
  });
  return server;
}

serveStdio(makeServer);
