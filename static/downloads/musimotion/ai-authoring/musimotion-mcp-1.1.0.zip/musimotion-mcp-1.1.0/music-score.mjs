import * as z from 'zod/v4';
import { fieldText } from './scene-plan.mjs';

const motif = z.array(z.number().int().min(-1).max(10)).min(4).max(16)
  .refine(notes => notes.some(note => note >= 0), 'Include at least one pitched note in this part.')
  .describe('Scale degrees, with -1 for a rest and 0 for the tonic. Include 4–16 entries and at least one note.');

export const musicScore = z.strictObject({
  version: z.literal(1),
  title: fieldText(50),
  style: z.enum(['techno', 'house', 'breakbeat', 'ambient', 'retro', 'shamisen']),
  tempo: z.number().int().min(60).max(180).describe('Beats per minute.'),
  bars: z.number().int().min(2).max(16),
  rootMIDI: z.number().int().min(32).max(47).describe('MIDI note of the bass tonic.'),
  bass: motif,
  lead: motif,
  brightness: z.number().min(0).max(1).describe('Dark (0) to bright (1) timbre.'),
  activity: z.number().min(0).max(1).describe('Sparse (0) to busy (1) arrangement.'),
  ensemble: z.enum(['automatic', 'electronic', 'session', 'chamber']).optional(),
});
