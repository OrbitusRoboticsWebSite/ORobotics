import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/client';
import { StdioClientTransport } from '@modelcontextprotocol/client/stdio';

const executable = fileURLToPath(new URL('../server.mjs', import.meta.url));
const example = JSON.parse(await readFile(new URL('../examples/lantern-festival.musiplan.json', import.meta.url)));
const create = (client, args) => client.callTool({ name: 'create_scene_plan', arguments: args });

async function connect(t, mode = 'auto') {
  const folder = await mkdtemp(join(tmpdir(), 'musimotion-mcp-'));
  const client = new Client({ name: 'musimotion-contract-test', version: '1.0' }, { versionNegotiation: { mode } });
  t.after(async () => {
    await client.close();
    await rm(folder, { recursive: true, force: true });
  });
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [executable, '--output-dir', folder],
  });
  await client.connect(transport);
  return { client, folder };
}

for (const [mode, era] of [['auto', 'modern'], ['legacy', 'legacy']]) {
  test(`MCP ${era} client discovers tools and creates a portable editable scene`, async t => {
    const { client, folder } = await connect(t, mode);
    assert.equal(client.getProtocolEra(), era);
    assert.equal(client.getNegotiatedProtocolVersion(), era === 'modern' ? '2026-07-28' : '2025-11-25');
    const { tools } = await client.listTools();
    assert.deepEqual(tools.map(tool => tool.name).sort(), ['create_music_score', 'create_scene_plan', 'prepare_scene_brief']);
    const schema = tools.find(tool => tool.name === 'create_scene_plan').inputSchema;
    assert.equal(schema.additionalProperties, false);
    assert.equal(schema.properties.cues.maxItems, 8);
    assert.equal(schema.properties.headline.maxLength, 64);
    const result = await create(client, example);
    assert.ok(!result.isError, JSON.stringify(result.content));
    const { filePath, fileName, fileUri, plan } = result.structuredContent;
    assert.equal(dirname(filePath), folder);
    assert.equal(fileURLToPath(fileUri), filePath);
    assert.match(fileName, /^lantern-festival-[\w-]+\.musiplan\.json$/);
    assert.deepEqual(plan, example);
    assert.deepEqual(JSON.parse(await readFile(filePath, 'utf8')), example);
    assert.equal(result.content[1].text, await readFile(filePath, 'utf8'));
    assert.ok((await stat(filePath)).size <= 65536);
  });
}

test('ambiguous, specific, and host-identified conflicting briefs', async t => {
  const { client, folder } = await connect(t);
  const review = async args => (await client.callTool({
    name: 'prepare_scene_brief', arguments: args,
  })).structuredContent;
  assert.equal((await review({ brief: 'Make a nice intro' })).status, 'needs_clarification');
  assert.equal((await review({ brief: 'Lunar eclipse' })).status, 'ready');
  const clarify = { question: 'Which run time should I use?', choices: ['12 seconds', '45 seconds'] };
  assert.deepEqual(await review({ brief: '12 seconds or 45 seconds', clarify }),
    { status: 'needs_clarification', ...clarify });
  assert.deepEqual(await readdir(folder), []);
});

test('rejects malformed and unsupported content before creating files', async t => {
  const { client, folder } = await connect(t);
  const cue = example.cues[0];
  const invalid = [
    { spatialMusicVideo: 'unknown' }, { musicVideoTempo: 128 }, { spatialMusicVideo: 'chromaNova', musicVideoTempo: 181 },
    { version: 2 }, { presentationTitle: ' ' }, { duration: 0 }, { duration: 121 },
    { outputPath: '/tmp/override.json' }, { artifactURL: 'file:///private' },
    { backgroundHex: '#000000' }, { imagePrompt: 'a'.repeat(421) },
    { cues: Array(9).fill(cue) }, { cues: [{ ...cue, end: cue.start }] },
    { cues: [{ ...cue, content: 'triangle' }] }, { cues: [{ ...cue, z: 1 }] },
    { cues: [{ ...cue, motion: 'unsupported' }] }, { cues: [{ ...cue, x: -0.1 }] },
    { spatialEffect: 'fallingBalls', spatialObjectCount: 1 }, { spatialObjectCount: 10 },
  ];
  for (const patch of invalid) {
    const result = await create(client, { ...example, ...patch });
    assert.equal(result.isError, true, JSON.stringify(patch));
  }
  assert.deepEqual(await readdir(folder), []);
});

test('identical concurrent requests create independent files and preserve full Unicode titles', async t => {
  const { client, folder } = await connect(t);
  const plan = { version: 1, presentationTitle: '../春 🌞', headline: '𠮷'.repeat(64), duration: 5 };
  const output = await Promise.all(Array.from({ length: 4 }, () => create(client, plan)));
  const paths = new Set();
  for (const result of output) {
    assert.ok(!result.isError, JSON.stringify(result.content));
    const { filePath } = result.structuredContent;
    assert.equal(dirname(filePath), folder);
    assert.deepEqual(JSON.parse(await readFile(filePath)), plan);
    paths.add(filePath);
  }
  assert.equal(paths.size, 4);
  assert.equal((await readdir(folder)).length, 4);
  assert.equal((await create(client, { ...plan, headline: plan.headline + '𠮷' })).isError, true);
});

test('external composer can save a score and receives useful field errors', async t => {
  const { client, folder } = await connect(t);
  const score = JSON.parse(await readFile(new URL('../examples/lantern-pulse.musiscore.json', import.meta.url)));
  const compose = args => client.callTool({ name: 'create_music_score', arguments: args });
  const result = await compose(score);
  assert.ok(!result.isError, JSON.stringify(result.content));
  assert.deepEqual(result.structuredContent.score, score);
  assert.match(result.structuredContent.fileName, /^lantern-pulse-[\w-]+\.musiscore\.json$/);
  assert.equal(await readFile(result.structuredContent.filePath, 'utf8'), result.content[1].text);
  assert.deepEqual(JSON.parse(result.content[1].text), score);
  for (const patch of [{ style: 'unknown' }, { title: ' ' }, { tempo: 180.5 }, { tempo: 59 },
    { bars: 17 }, { rootMIDI: 48 }, { bass: [0, 1, 2] }, { lead: Array(17).fill(0) },
    { lead: [-1, -1, -1, -1] }, { bass: [0, -2, -1, 1] }, { brightness: -0.1 }, { activity: 1.1 },
    { source: 'file:///music.mp3' }, { ensemble: 'band' }, { version: 2 }]) {
    assert.equal((await compose({ ...score, ...patch })).isError, true, JSON.stringify(patch));
  }
  assert.equal((await readdir(folder)).length, 1);
});

test('external director writes an editable spatial music video plan', async t => {
  const { client } = await connect(t);
  const plan = JSON.parse(await readFile(new URL('../examples/beat-rail.musiplan.json', import.meta.url)));
  const result = await create(client, plan);
  assert.ok(!result.isError, JSON.stringify(result.content));
  assert.deepEqual(JSON.parse(await readFile(result.structuredContent.filePath)), plan);
});
