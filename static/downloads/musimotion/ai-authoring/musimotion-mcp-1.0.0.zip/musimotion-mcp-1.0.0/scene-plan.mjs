import * as z from 'zod/v4';

/** The native draft format measures strings in Unicode scalar values. */
export function fieldText(maximum, { optional = false } = {}) {
  const minimum = optional ? 0 : 1;
  return z.string().trim().refine(value => {
    const length = [...value].length;
    return length >= minimum && length <= maximum && !/[\uD800-\uDFFF]/u.test(value);
  }, { message: `Use ${minimum}–${maximum} Unicode characters.` })
    .meta({ minLength: minimum, maxLength: maximum });
}

const shapes = ['rectangle', 'roundedRectangle', 'circle', 'star'];
const unit = z.number().min(0).max(1);
const motions = ['none', 'riseAndSettle', 'elasticReveal', 'focusPull', 'heartbeat',
  'pendulum', 'orbit', 'sweepAway', 'foldDown', 'tumbleOut'];

const cue = z.strictObject({
  name: fieldText(48).describe('Editable layer name.'),
  kind: z.enum(['text', 'shape']),
  content: fieldText(84).describe('Visible text, or a shape: rectangle, roundedRectangle, circle, star.'),
  start: unit.describe('Start as a fraction of scene duration, from 0 to 1.'),
  end: unit.describe('End as a fraction of scene duration, greater than start.'),
  x: unit.describe('Horizontal center. 0 is left and 1 is right.'),
  y: unit.describe('Vertical center. 0 is top and 1 is bottom.'),
  motion: z.enum(motions),
}).superRefine((value, context) => {
  if (value.end <= value.start) {
    context.addIssue({ code: 'custom', path: ['end'], message: 'end must be greater than start.' });
  }
  if (value.kind === 'shape' && !shapes.includes(value.content)) {
    context.addIssue({ code: 'custom', path: ['content'], message: `Use one of: ${shapes.join(', ')}.` });
  }
});

const color = z.string().regex(/^[0-9A-Fa-f]{6}$/, 'Use six hex digits without a # prefix.');
export const scenePlan = z.strictObject({
  version: z.literal(1),
  presentationTitle: fieldText(54).describe('Project title.'),
  headline: fieldText(64).describe('Main on-screen text.'),
  duration: z.number().min(5).max(120).describe('Scene duration in seconds.'),
  subtitle: fieldText(84, { optional: true }).optional(),
  callToAction: fieldText(42, { optional: true }).optional(),
  imagePrompt: fieldText(420, { optional: true }).describe('Optional artwork description for the user to generate in the editor.').optional(),
  layout: z.enum(['cinematicCenter', 'splitFocus', 'lowerThird', 'poster']).optional(),
  cameraMove: z.enum(['pushIn', 'pullOut', 'panLeft', 'panRight', 'panUp', 'panDown']).optional(),
  backgroundHex: color.optional(),
  textHex: color.optional(),
  accentHex: color.optional(),
  usesSumiInk: z.boolean().optional(),
  spatialEffect: z.enum(['none', 'fallingBalls', 'risingBalloons']).optional(),
  spatialObjectCount: z.number().int().min(0).max(120).describe('Use 0 with no effect, or 8–120 with a spatial effect.').optional(),
  cues: z.array(cue).max(8).describe('Timed text and shape layers in addition to the main headline.').optional(),
}).superRefine((plan, context) => {
  const count = plan.spatialObjectCount;
  if (count === undefined) return;
  const hasEffect = plan.spatialEffect !== undefined && plan.spatialEffect !== 'none';
  if ((hasEffect && count < 8) || (!hasEffect && count !== 0)) {
    context.addIssue({ code: 'custom', path: ['spatialObjectCount'],
      message: 'Use 8–120 with a spatial effect, or 0 when no effect is set.' });
  }
});
