ROB VIPER SECURITY OPERATIONS HANDBOOK / EXERCISES / 1.0
Copyright 2026 OrbitusRobotics LLC. All rights reserved.
Free teaching companion: https://www.orbitusrobotics.com/books/rob-viper-security-operations/

Requires Python 3.10+. Review these short scripts before running them.
No dependencies are installed, no network requests are made, and no security
settings are changed. The optional scanners are separate installations.

1. Create a NEW private training directory under an existing parent:
   python3 prepare_lab.py --output /absolute/new/viper-training
   Add --include-limit-fixture for a 65 MiB sparse coverage fixture.
   Existing paths are refused. A partial failure is left for your inspection.
2. Inspect manifest.json, files, and the rule source. The EICAR fixture can
   intentionally trigger installed antivirus. Record that result; do not
   disable protection to force the exercise through.
3. In Viper Threat Center, choose only the relevant generated subdirectory.
   Malware: clean should have no signature; eicar should report an informative
   EICAR test match; limits should report incomplete coverage if generated.
   Rules: select rules/marker.yar, then separately scan positive and negative.
   Vulnerabilities: scan dependencies. This lockfile describes lodash 4.17.20
   without installing it. Confirm nonzero supported targets and package records.
   CVE-2021-23337 was observed in the edition baseline; current counts vary.
4. Export each JSON report. Review with:
   python3 review_report.py /absolute/path/report.json
   Exit 0 means completed with only low/info findings and recognized coverage;
   it does NOT approve a release or claim the target safe. Exit 1 needs finding
   review. Exit 2 means malformed, unsuccessful or unestablished coverage.
   This teaching check recognizes Viper 0.7 schema 1 and its English coverage
   note, not arbitrary SARIF/vendor output or future schema changes.
5. Complete case-template.txt. Keep reports local unless approved for sharing.

CLI users with an authorized Viper source checkout can build with swift build
and use .build/debug/viper-scan. The book is free; this bundle does not supply
a production-signed installer, managed service, scanner engines or databases.
Commands and hash arguments are documented in Chapters 10-12, 18 and 21.

An engine error, missing database, zero supported inventory or skipped file is
not a clean pass. Test both positive and negative controls. Never install the
old dependency from the metadata fixture. No real malware is needed.
