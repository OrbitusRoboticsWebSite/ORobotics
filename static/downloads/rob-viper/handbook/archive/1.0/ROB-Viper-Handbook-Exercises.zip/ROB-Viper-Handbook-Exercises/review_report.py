#!/usr/bin/env python3
"""Summarize a Viper schema-1 report; never automatically approve a release.

Exit 0: completed, recognized coverage, only low/info findings (still review).
Exit 1: completed, medium/high/critical or unknown-severity findings need review.
Exit 2: malformed, unsuccessful, or unestablished coverage. No data is uploaded.
"""
import argparse
from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import re
import uuid

MAX_BYTES=8*1024*1024
SEVERITIES={'critical','high','medium','low','info','unknown'}

def unique_object(pairs):
    result={}
    for k,v in pairs:
        if k in result: raise ValueError('Duplicate JSON property: '+k)
        result[k]=v
    return result

def review(raw):
    if len(raw)>MAX_BYTES: raise ValueError('Report exceeds 8 MiB review bound.')
    r=json.loads(raw, object_pairs_hook=unique_object)
    if not isinstance(r,dict) or type(r.get('schemaVersion')) is not int or r['schemaVersion']!=1:
        raise ValueError('Expected Viper schemaVersion 1.')
    if r.get('kind') not in {'malware','vulnerabilities','rules','posture'}:
        raise ValueError('Unrecognized scan kind.')
    if r.get('outcome') not in {'completed','incomplete','failed','cancelled','timedOut'}:
        raise ValueError('Missing or unrecognized outcome.')
    uuid.UUID(r.get('id',''))
    dates=[]
    for key in ['started','finished']:
        if not isinstance(r.get(key),str): raise ValueError('Missing timestamp.')
        dt=datetime.fromisoformat(r[key].replace('Z','+00:00'))
        if dt.tzinfo is None: raise ValueError('Timestamp needs a timezone.')
        dates.append(dt)
    if dates[1]<dates[0]: raise ValueError('Finished precedes started.')
    for key in ['target','engineVersion','engineSHA256','databaseDetail']:
        if not isinstance(r.get(key),str): raise ValueError('Missing text field: '+key)
    if not r['target'].strip(): raise ValueError('Missing target.')
    findings=r.get('findings'); notes=r.get('notes')
    if not isinstance(findings,list) or len(findings)>1000: raise ValueError('Invalid findings list.')
    if not isinstance(notes,list) or not all(isinstance(x,str) for x in notes): raise ValueError('Invalid coverage notes.')
    counts=Counter()
    for f in findings:
        if not isinstance(f,dict) or f.get('severity') not in SEVERITIES: raise ValueError('Invalid finding severity.')
        if not all(isinstance(f.get(k),str) for k in ['id','title','subject','evidence','recommendation']):
            raise ValueError('Incomplete finding.')
        counts[f['severity']]+=1
    result={'id':r['id'],'kind':r['kind'],'target':r['target'],'outcome':r['outcome'],
            'findings':len(findings),'severityCounts':dict(counts),'notes':notes,
            'decision':'Human review required; this script never approves a release.'}
    if r['outcome']!='completed':
        result['coverage']='Run did not complete.'; return result,2
    if r['kind']!='posture' and (not re.fullmatch('[a-fA-F0-9]{64}',r['engineSHA256']) or not r['engineVersion']):
        raise ValueError('Completed scan lacks engine identity.')
    if r['kind']=='rules' and not re.fullmatch('[a-fA-F0-9]{64}',r.get('ruleSHA256','')):
        raise ValueError('Completed rule scan lacks reviewed rule hash.')
    if r['kind']=='vulnerabilities':
        inventories=[re.match(r'(\d+) supported dependency targets reported; (\d+) package records\.',n) for n in notes]
        inventories=[m for m in inventories if m]
        if len(inventories)!=1 or int(inventories[0][1])==0 or int(inventories[0][2])==0:
            result['coverage']='Supported package coverage was not established.'; return result,2
        result['inventoryTargets']=int(inventories[0][1]); result['packageRecords']=int(inventories[0][2])
    result['coverage']='Completed within reported scope; inspect all notes and skipped targets.'
    return result, int(any(counts[s] for s in ['critical','high','medium','unknown']))

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('report',type=Path); args=p.parse_args()
    try:
        with args.report.open('rb') as f: raw=f.read(MAX_BYTES+1)
        result,status=review(raw)
    except (OSError,ValueError,TypeError,AttributeError,OverflowError,RecursionError) as exc:
        print(json.dumps({'decision':'Do not treat this input as approval.','error':str(exc)},ensure_ascii=True)); return 2
    # JSON escapes control characters; never render report strings as terminal commands.
    print(json.dumps(result,indent=2,ensure_ascii=True)); return status

if __name__=='__main__': raise SystemExit(main())
