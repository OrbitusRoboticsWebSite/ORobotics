#!/usr/bin/env python3
"""Create harmless, non-executable teaching data in a NEW directory only.

No network requests, package installation, policy changes or actual malware.
EICAR can intentionally trigger another installed antivirus product.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

RULE = '''rule Viper_Training_Marker
{
    meta:
        purpose = "Harmless handbook exercise"
        owner = "Orbitus Robotics training"
        revision = "1.0"
    strings:
        $marker = "VIPER-HANDBOOK-TRAINING-ONLY"
    condition:
        filesize < 1024 and $marker
}
'''

def prepare(output, include_limit=False):
    output = Path(output).expanduser()
    if not output.is_absolute():
        raise ValueError('Choose an absolute output path.')
    # mkdir without exist_ok prevents overwriting files or following an existing
    # output-directory symlink. Do not remove a partial directory on failure.
    os.umask(0o077)
    output.mkdir(mode=0o700)
    files = {
        'clean/clean.txt': b'Ordinary harmless training text.\n',
        'eicar/eicar-test.txt': b'X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*',
        'positive/marker.txt': b'VIPER-HANDBOOK-TRAINING-ONLY\n',
        'negative/ordinary.txt': b'An unrelated negative control.\n',
        'rules/marker.yar': RULE.encode(),
        'dependencies/package-lock.json': (json.dumps({
            'name': 'viper-metadata-only-training', 'version': '1.0.0', 'lockfileVersion': 3,
            'packages': {'': {'dependencies': {'lodash': '4.17.20'}},
                         'node_modules/lodash': {'version': '4.17.20'}}}, indent=2)+'\n').encode(),
    }
    for name, data in files.items():
        target = output/name
        target.parent.mkdir(mode=0o700, exist_ok=True)
        with target.open('xb') as f:
            f.write(data)
    if include_limit:
        (output/'limits').mkdir(mode=0o700)
        with (output/'limits/over-limit.bin').open('xb') as f:
            f.truncate(65*1024*1024)
    entries = {}
    for path in sorted(output.rglob('*')):
        if path.is_file():
            digest = hashlib.sha256()
            with path.open('rb') as f:
                for chunk in iter(lambda: f.read(1024*1024), b''):
                    digest.update(chunk)
            entries[str(path.relative_to(output))] = {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
    manifest = {'edition': '1.0', 'harmless_training_data': True,
                'expected': {'clean': 'completed; no signatures', 'eicar': 'informational EICAR match',
                    'positive': 'Viper_Training_Marker match', 'negative': 'no YARA match',
                    'dependencies': 'supported lodash inventory; advisory count varies with database',
                    'limits': 'if generated: incomplete ClamAV coverage; never a clean pass'},
                'files': entries}
    (output/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', required=True, help='Absolute path to a new directory; parent must exist.')
    p.add_argument('--include-limit-fixture', action='store_true', help='Also create a 65 MiB sparse coverage-test file.')
    args=p.parse_args()
    try:
        result=prepare(args.output, args.include_limit_fixture)
    except (OSError, ValueError) as exc:
        p.exit(2, f'Fixture creation stopped: {exc}\nNo existing directory is overwritten.\n')
    print(json.dumps({'created': str(Path(args.output).expanduser()), 'files': len(result['files']),
                      'ruleSHA256': result['files']['rules/marker.yar']['sha256']}, indent=2))

if __name__=='__main__': main()
